# LABUBU — $LABU (Final Marketing Build, GitHub Pages)
1) Upload **all files** to repo root, keep the `assets/` folder.
2) Settings → Pages → Deploy from a branch → main / (root).
3) Update links/CA in `config.js` if needed.
4) Hard refresh after deploy (Ctrl/Cmd+Shift+R).