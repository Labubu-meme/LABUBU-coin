// === Official links & contract ===
const CONFIG = {
  CA: "FpNfd5aGiYM5eQcDRM66SGY3ahi3BjeBgjGy82swpump",
  PUMPFUN: "https://pump.fun/FpNfd5aGiYM5eQcDRM66SGY3ahi3BjeBgjGy82swpump",
  RAYDIUM: "https://raydium.io/",
  SOLSCAN: "https://solscan.io/token/FpNfd5aGiYM5eQcDRM66SGY3ahi3BjeBgjGy82swpump",
  DEXSCREENER: "https://dexscreener.com/solana/FpNfd5aGiYM5eQcDRM66SGY3ahi3BjeBgjGy82swpump",
  X: "https://x.com/labubu_meme",
  TG: "https://t.me/labubu_meme",
  TIKTOK: "https://www.tiktok.com/@labubu.meme"
};
